
package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SearchGUIDoctor extends JPanel
{
    public static void main(String[] args)
    {
        SearchGUIDoctor j = new SearchGUIDoctor();
    }
}
