
package bd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

public class Appointment_Frame extends JFrame{
    
    private JLabel appointmentLabel;
    private JButton accept,reject , save;
    private JPanel p1,AppointmentHeader , AppointmentPanel ;
    private JScrollPane scrollp;
    private JTable table;
    
    public Appointment_Frame() {
        super("Appointment");
        
        setLayout(null);

        p1 = new JPanel();  
        p1.setBounds(800, 0, 200, 600);
        p1.setBackground(Color.yellow);
        p1.setLayout(null); // if you delete this line, you wouldn't be able to adjust where to place the picture.    
        p1.setBorder(BorderFactory.createLineBorder(Color.black));
        JLabel picLabel = new JLabel(); // creating the Jlabel.
        picLabel.setBounds(10, 10, 165, 165); // setting the bounds of the JLabel.
        p1.add(picLabel); // adding the JLabel to the panel.
        ImageIcon Image1 = new ImageIcon(""); // the track of the picture 
        Image img1 = Image1.getImage(); // converting the ImageIcon to Image. 
        Image newImg1 = img1.getScaledInstance(picLabel.getWidth(), picLabel.getHeight(), Image.SCALE_SMOOTH); // the important step which is for fitting the picture into the label.
        ImageIcon imageIc = new ImageIcon(newImg1); // finally, setting the image to the JLabel
        picLabel.setIcon(imageIc); // adding the picture into the JLabel (not sure lol).
        JButton home,profile,history,request,invitation,appointment;
        home = new JButton("Home");
        home.setBounds(40, 200, 120, 20);
        p1.add(home);
        profile = new JButton("Profile");
        profile.setBounds(40, 240, 120, 20);
        p1.add(profile);
        history = new JButton("History");
        history.setBounds(40, 280, 120, 20);
        p1.add(history);
        request = new JButton("Requests");
        request.setBounds(40, 320, 120, 20);
        p1.add(request);
        invitation = new JButton("Invitations");
        invitation.setBounds(40, 360, 120, 20);
        p1.add(invitation);
        appointment = new JButton("Appointments");
        appointment.setBounds(40, 400, 120, 20);
        p1.add(appointment);
        add(p1);
        ////////////////////////////////////////////////////////////////////////
        AppointmentHeader = new JPanel(null);
        AppointmentHeader.setBounds(0, 0, 800, 100);
        AppointmentHeader.setBackground(Color.white);
        AppointmentHeader.setBorder(BorderFactory.createEtchedBorder());
        AppointmentHeader.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
        appointmentLabel = new JLabel("Appointments");
        appointmentLabel.setFont(new Font("", 1, 26));
        appointmentLabel.setForeground(new Color(50, 50, 25));
        appointmentLabel.setBounds(309, 35, 182, 30);
        AppointmentHeader.add(appointmentLabel);
        add(AppointmentHeader);
        
        
        AppointmentPanel = new JPanel(null);
        AppointmentPanel.setBounds(0,100, 800, 600);
        AppointmentPanel.setBackground(Color.gray);
        add(AppointmentPanel);
        
        accept = new JButton("Back");
        accept.setBounds(25, 450, 80, 23);
        save = new JButton("Save");
        save.setBounds(362, 450, 75, 23);
        AppointmentPanel.add(save);
        AppointmentPanel.add(accept);
        reject = new JButton("Delete");
        reject.setBounds(695, 450, 80, 23);
        AppointmentPanel.add(reject);
        
        scrollp = new JScrollPane();
        table = new JTable();
        table.setModel(new DefaultTableModel(
            new Object [][] {
                {null, null, null, null , null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Appointment ID", "Donor ID", "Recevier ID", "Hospital", "Date"
            }
        ));
        scrollp.setViewportView(table);
        scrollp.setBounds(25, 50, 750, 246);
        AppointmentPanel.add(scrollp);
        
        JLabel AppointmentCount = new JLabel("Number of the appointment is = " + table.getRowCount());
        AppointmentCount.setBounds(225, 316, 350, 25);
        AppointmentCount.setFont(new Font("" , 1 , 18));
        AppointmentCount.setForeground(Color.BLACK);
        AppointmentPanel.add(AppointmentCount);
        ////////////////////////////////////////////////////////////////////////////////////
    }
    public static void main(String args[]) 
   { 
       Appointment_Frame a = new Appointment_Frame();
       a.setVisible(true);
       a.setSize(1000, 628);
       a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
   }

}
