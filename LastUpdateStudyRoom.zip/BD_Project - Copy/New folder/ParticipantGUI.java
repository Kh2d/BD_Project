
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ParticipantGUI extends JFrame
{
    private JPanel MainPanel , ParticipantHeader , ParticipantPanel;
    private JLabel l1, ParticipantHeaderTitle ,ParticipantTitle, ParticipantHeaderImage;
    private JButton[] b,b1;
    
    
    public ParticipantGUI()
    {
        getContentPane().setBackground(Color.GRAY);
        setTitle("Blood Donation");
        setLayout(null);
        //
        
        MainPanel = new JPanel(null);
        MainPanel.setBounds(800, 0, 200, 600);
        MainPanel.setBackground(new java.awt.Color(204, 204, 204));
        MainPanel.setBorder(BorderFactory.createEtchedBorder());
        
        l1 = new JLabel();
        l1.setFont(new Font("", 0, 20));
        Icon s = new ImageIcon();
        l1.setIcon(s);
        l1.setBounds(18, 50, 185, 135);
        
        b = new JButton[7];
        b[0] = new JButton("Home");
        b[0].setBounds(18, 200, 160, 40);
        
        b[1]= new JButton("Profile");
        b[1].setBounds(18, 245, 160, 40);
        
        b[2]= new JButton("History");
        b[2].setBounds(18, 290, 160, 40);
        
        b[3]= new JButton("Requests");
        b[3].setBounds(18, 335, 160, 40);
        
        b[4]= new JButton("Invitation");
        b[4].setBounds(18, 380, 160, 40);
        
        b[5]= new JButton("Appointment");
        b[5].setBounds(18, 425, 160, 40);
        
        b[6]= new JButton("Log Out");
        b[6].setBounds(18, 550, 160, 40);
        
       
       
        //
        ParticipantHeader = new JPanel(null);
        ParticipantHeader.setBounds(0, 0, 800, 100);
        ParticipantHeader.setBackground(Color.white);
        ParticipantHeader.setBorder(BorderFactory.createEtchedBorder());
        ParticipantHeaderTitle = new JLabel("New Operation");
        ParticipantHeaderTitle.setFont(new Font("", 1, 26));
        ParticipantHeaderTitle.setBounds(305, 40, 190, 30);
        ParticipantHeader.add(ParticipantHeaderTitle);
        Icon s1 = new ImageIcon("");
        ParticipantHeaderImage = new JLabel(s);
        ParticipantHeaderImage.setBounds(200 , 5 , 90 , 90);
        ParticipantHeader.add(ParticipantHeaderImage);
        /////
         add(MainPanel);
        add(ParticipantHeader);
        MainPanel.add(l1);
        for (JButton b2 : b) {
            MainPanel.add(b2);
        }
        ////////////////////////////////////////////////////////////////////////
        
        ParticipantPanel=new JPanel(null);
        ParticipantPanel.setBounds(0, 100, 800, 500);
        ParticipantPanel.setBackground(Color.gray);
        add(ParticipantPanel);
        ParticipantTitle=new JLabel("Please choose the operation :");
        ParticipantTitle.setFont(new Font("",1,18));
        ParticipantTitle.setForeground(Color.white);
        ParticipantTitle.setBounds(250, 150, 400, 25);
        ParticipantPanel.add(ParticipantTitle);
        b1= new JButton[2];
        b1[0] = new JButton("Donate");
        b1[0].setBounds(50, 350, 120, 30);
        b1[1] = new JButton("Recieve");
        b1[1].setBounds(650, 350, 120, 30);
       
        // p3.add(b1);
        for (JButton b11 : b1) {
            ParticipantPanel.add(b11);
        }
        
    }
    
     public static void main(String[] args) {
        ParticipantGUI a = new ParticipantGUI();
        a.setVisible(true);
        a.setDefaultCloseOperation(EXIT_ON_CLOSE);
        a.setSize(1000, 628);
        a.setResizable(false);
    }
}
  