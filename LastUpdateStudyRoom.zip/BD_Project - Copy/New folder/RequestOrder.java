
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION;
import javax.swing.table.DefaultTableModel;

public class RequestOrder extends JFrame{
    
    private JLabel RequestRequestOrderLabel;
    private JButton RequestOrderBackButton,RequestOrderSendButton ;
    private JPanel p1,RequestOrderHeader , RequestOrderPanel ;
    private JScrollPane scrollp;
    private JTable table;
    
    public RequestOrder() {
        super("RequestOrder");
        
        setLayout(null);

        p1 = new JPanel();  
        p1.setBounds(800, 0, 200, 600);
        p1.setBackground(Color.yellow);
        p1.setLayout(null); // if you delete this line, you wouldn't be able to adjust where to place the picture.    
        p1.setBorder(BorderFactory.createLineBorder(Color.black));
        JLabel picLabel = new JLabel(); // creating the Jlabel.
        picLabel.setBounds(10, 10, 165, 165); // setting the bounds of the JLabel.
        p1.add(picLabel); // adding the JLabel to the panel.
        ImageIcon Image1 = new ImageIcon(""); // the track of the picture 
        Image img1 = Image1.getImage(); // converting the ImageIcon to Image. 
        Image newImg1 = img1.getScaledInstance(picLabel.getWidth(), picLabel.getHeight(), Image.SCALE_SMOOTH); // the important step which is for fitting the picture into the label.
        ImageIcon imageIc = new ImageIcon(newImg1); // finally, setting the image to the JLabel
        picLabel.setIcon(imageIc); // adding the picture into the JLabel (not sure lol).
        JButton home,profile,history,request,invitation,appointment;
        home = new JButton("Home");
        home.setBounds(40, 200, 120, 20);
        p1.add(home);
        profile = new JButton("Profile");
        profile.setBounds(40, 240, 120, 20);
        p1.add(profile);
        history = new JButton("History");
        history.setBounds(40, 280, 120, 20);
        p1.add(history);
        request = new JButton("Requests");
        request.setBounds(40, 320, 120, 20);
        p1.add(request);
        invitation = new JButton("Invitations");
        invitation.setBounds(40, 360, 120, 20);
        p1.add(invitation);
        appointment = new JButton("Appointments");
        appointment.setBounds(40, 400, 120, 20);
        p1.add(appointment);
        add(p1);
        ////////////////////////////////////////////////////////////////////////
        RequestOrderHeader = new JPanel(null);
        RequestOrderHeader.setBounds(0, 0, 800, 100);
        RequestOrderHeader.setBackground(Color.white);
        RequestOrderHeader.setBorder(BorderFactory.createEtchedBorder());
        RequestOrderHeader.setBorder(BorderFactory.createEtchedBorder());
        RequestRequestOrderLabel = new JLabel("Request Order");
        RequestRequestOrderLabel.setFont(new Font("", 1, 26));
        RequestRequestOrderLabel.setForeground(new Color(50, 50, 25));
        RequestRequestOrderLabel.setBounds(309, 35, 182, 30);
        RequestOrderHeader.add(RequestRequestOrderLabel);
        add(RequestOrderHeader);
        
        ////////////////////////////////////////////////////////////////////////
      
        RequestOrderPanel = new JPanel(null);
        RequestOrderPanel.setBounds(0,100, 800, 600);
        RequestOrderPanel.setBackground(Color.gray);
        add(RequestOrderPanel);
        
        RequestOrderBackButton = new JButton("Back");
        RequestOrderBackButton.setBounds(25, 450, 80, 23);
        RequestOrderPanel.add(RequestOrderBackButton);
        
        RequestOrderSendButton = new JButton("Send");
        RequestOrderSendButton.setBounds(695, 450, 80, 23);
        RequestOrderPanel.add(RequestOrderSendButton);
        RequestOrderSendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) 
            {
                JOptionPane.showConfirmDialog(null, "Are you sure you want to send request?", "Confirmation", JOptionPane.YES_NO_OPTION);
            }

        });
       
        scrollp = new JScrollPane();
        table = new JTable();
        table.setModel(new DefaultTableModel(
            new Object [][] {
                {null, null, null, null , null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                 "Name", "BLood Type"
            }
        ));
        scrollp.setViewportView(table);
        scrollp.setBounds(25, 50, 750, 246);
        RequestOrderPanel.add(scrollp);
        
        JLabel AppointmentCount = new JLabel("Number of the Donors is = " + table.getRowCount());
        AppointmentCount.setBounds(25, 350, 350, 30);
        AppointmentCount.setFont(new Font("" , 1 , 18));
        AppointmentCount.setForeground(Color.BLACK);
        RequestOrderPanel.add(AppointmentCount);
       
        ////////////////////////////////////////////////////////////////////////////////////
    }
    public static void main(String args[]) 
   { 
       RequestOrder a = new RequestOrder();
       a.setVisible(true);
       a.setSize(1000, 628);
       a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
   }

}
